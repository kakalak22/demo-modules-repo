rm -rf /data/adb/zygisksu 2>/dev/null
rm /data/adb/service.d/.zn_cleanup.sh 2>/dev/null
rm /data/adb/ksu/bin/znctl 2>/dev/null
rm /data/adb/ap/bin/znctl 2>/dev/null
