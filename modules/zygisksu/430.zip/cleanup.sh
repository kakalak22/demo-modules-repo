if [ -f /data/adb/modules/zygisksu/disable ]; then
  cat /data/adb/modules/zygisksu/module.prop.orig > /data/adb/modules/zygisksu/module.prop
  rm /data/adb/service.d/.zn_cleanup.sh
fi
